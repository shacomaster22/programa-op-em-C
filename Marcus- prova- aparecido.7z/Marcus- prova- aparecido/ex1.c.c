

#include <stdio.h>


int main()
{
 int v1, v2, v3, result;

          printf("escreva o primeiro valor\n");
            scanf("%d",&v1);
          printf("escreva o segundo valor\n");
            scanf("%d",&v2);
          printf("escreva o segundo valor\n");
            scanf("%d",&v3);
           result = v1 + v2 + v3;
          printf("a soma de todos os valores sao: %d",result);

   return 0;
}
